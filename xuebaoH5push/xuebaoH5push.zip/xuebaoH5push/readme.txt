﻿本程序供免费使用，对于使用问题不负责任
仅供我们用户测试使用
项目更新
https://github.com/xuebaodev/wawaji/xuebaoH5push


如果开机没有自启动，则切换到本目录。输入如下命令运行。
java -classpath '.:./lib/JavaSerial-0.9.jar' pusherApp






